﻿namespace Codecool.Quest.Models {
    public enum CellType {
        EMPTY, FLOOR, WALL, MOB, ITEM, DOOR, LEVEL2, LEVEL3, CASTLE, WIN
    }
}
