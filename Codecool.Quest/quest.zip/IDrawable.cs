﻿namespace Codecool.Quest.Models {
    public interface IDrawable {
        string TileName { get; }
    }
}
