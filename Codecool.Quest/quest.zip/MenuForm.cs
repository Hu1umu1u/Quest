﻿using Codecool.Quest.Models;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Threading;
using System;


namespace Codecool.Quest
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
            SetupMenu();
        }

        private void SetupMenu()
        {
            // Установка фонового изображения
            this.BackgroundImage = Image.FromFile(@"Resources\roguelikeDungeon_transparent.png");
            this.BackgroundImageLayout = ImageLayout.Tile;
            this.ClientSize = new Size(800, 600);
            this.Text = "Главное меню";

            // Создание кнопок
            Button startButton = CreateButton("Начать игру", 300, 200, StartGame);
            Button howToPlayButton = CreateButton("Как играть", 300, 270, ShowHowToPlay);
            Button aboutButton = CreateButton("Об авторе", 300, 340, ShowAbout);
            Button exitButton = CreateButton("Выход", 300, 410, ExitGame);

            // Добавление кнопок на форму
            this.Controls.Add(startButton);
            this.Controls.Add(howToPlayButton);
            this.Controls.Add(aboutButton);
            this.Controls.Add(exitButton);
        }

        private Button CreateButton(string text, int x, int y, EventHandler onClick)
        {
            Button button = new Button();
            button.Text = text;
            button.Size = new Size(200, 50);
            button.Location = new Point(x, y);
            button.Font = new Font("Arial", 12, FontStyle.Bold);
            button.BackColor = Color.LightGray;
            button.ForeColor = Color.Black;
            button.Click += onClick;
            return button;
        }

        // Обработчики кнопок
        private void StartGame(object sender, EventArgs e)
        {
            this.Hide(); // Скрыть меню
            MainForm gameForm = new MainForm(); // Создать форму игры
            gameForm.Show(); // Показать игру
        }

        private void ShowHowToPlay(object sender, EventArgs e)
        {
            MessageBox.Show("Инструкция:\nИспользуйте WASD для перемещения. ЛКМ для взаимодействия.",
                            "Как играть", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowAbout(object sender, EventArgs e)
        {
            MessageBox.Show("Игра разработана мной.\nПроект для учебной цели.",
                            "Об авторе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ExitGame(object sender, EventArgs e)
        {
            Application.Exit(); // Завершить приложение
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            this.SuspendLayout();
            // 
            // MenuForm
            // 
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1710, 844);
            this.HelpButton = true;
            this.Name = "MenuForm";
            this.Load += new System.EventHandler(this.MenuForm_Load);
            this.ResumeLayout(false);

        }

        private void MenuForm_Load(object sender, EventArgs e)
        {

        }
    }
}